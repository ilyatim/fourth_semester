package com.example.testcoursework.ui.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.testcoursework.R

class ProgressActivity : AppCompatActivity()
{

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress)
    }
}
