package com.example.testcoursework.viewmodel

import android.arch.lifecycle.ViewModel;

class WorkoutViewModel : ViewModel()
{
    // TODO: Implement the ViewModel
}
