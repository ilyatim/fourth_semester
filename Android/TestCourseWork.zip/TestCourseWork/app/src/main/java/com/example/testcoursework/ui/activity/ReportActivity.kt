package com.example.testcoursework.ui.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.testcoursework.R

class ReportActivity : AppCompatActivity()
{

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report)
    }
}
