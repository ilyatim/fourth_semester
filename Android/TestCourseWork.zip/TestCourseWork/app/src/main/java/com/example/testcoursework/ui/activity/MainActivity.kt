package com.example.testcoursework.ui.activity

import android.app.Activity
import android.arch.lifecycle.ViewModelProviders
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.FragmentTransaction
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.example.testcoursework.R
import com.example.testcoursework.data.PersonActivity
import com.example.testcoursework.data.Singleton
import com.example.testcoursework.databinding.ActivityMainBinding
import com.example.testcoursework.ui.mFragment.HomeFragment
import com.example.testcoursework.ui.mFragment.PersonFragment
import com.example.testcoursework.ui.mFragment.WorkoutFragment
import com.example.testcoursework.viewmodel.MyViewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.fitness.Fitness
import com.google.android.gms.fitness.FitnessOptions
import com.google.android.gms.fitness.data.DataType
import com.google.android.gms.fitness.request.DataReadRequest
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity()
{
    private val GOOGLE_FIT_PERMISSIONS_REQUEST_CODE = System.identityHashCode(this)
    private val LOG_TAG: String = "MainActivity"
    private val PERSON_ACTIVITY_STRING: String = "person_activity"
    private lateinit var pref: SharedPreferences
    private lateinit var binding: ActivityMainBinding

    private val onNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
        when (item.itemId)
        {
            R.id.navigation_home -> {
                transaction.replace(R.id.fragment, HomeFragment())
            }
            R.id.navigation_workout -> {

                transaction.replace(R.id.fragment, WorkoutFragment())
            }
            R.id.navigation_about_me -> {
                transaction.replace(R.id.fragment, PersonFragment())
            }
        }
        transaction.commit()
        return@OnNavigationItemSelectedListener true
    }


    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)

        supportFragmentManager.beginTransaction().add(R.id.fragment, HomeFragment()).commit()

        pref = getSharedPreferences("com.example.testcoursework", Context.MODE_PRIVATE)
        if(pref.contains(PERSON_ACTIVITY_STRING))
        {
            Singleton.personActivity = pref.getPersonActivityData(PERSON_ACTIVITY_STRING)
        }
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        val viewModel = ViewModelProviders.of(this).get(MyViewModel::class.java)
        binding.viewModel = viewModel
        binding.executePendingBindings()
        binding.navView.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener)

        //fitnessCreate()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?)
    {
        /*if(requestCode == Activity.RESULT_OK)
        {
            if(requestCode == GOOGLE_FIT_PERMISSIONS_REQUEST_CODE)
            {
                this.accessGoogleFit()
            }
        }*/
        super.onActivityResult(requestCode, resultCode, data)
    }

    /*private fun fitnessCreate()
    {
        val fitnessOptions = FitnessOptions.builder()
            .addDataType(DataType.TYPE_STEP_COUNT_DELTA, FitnessOptions.ACCESS_READ)
            .addDataType(DataType.AGGREGATE_STEP_COUNT_DELTA, FitnessOptions.ACCESS_READ)
            .build()
        if(!GoogleSignIn.hasPermissions(GoogleSignIn.getLastSignedInAccount(this), fitnessOptions))
        {
            GoogleSignIn.requestPermissions(
                this,
                GOOGLE_FIT_PERMISSIONS_REQUEST_CODE,
                GoogleSignIn.getLastSignedInAccount(this),
                fitnessOptions)
        }
        else
        {
            accessGoogleFit()
        }

    }
    private fun accessGoogleFit()
    {
        val cal = Calendar.getInstance()
        cal.time = Date()
        val endTime = cal.timeInMillis
        cal.add(Calendar.YEAR, -1)
        val startTime = cal.timeInMillis

        val readRequest = DataReadRequest.Builder()
            .aggregate(DataType.TYPE_STEP_COUNT_DELTA, DataType.AGGREGATE_STEP_COUNT_DELTA)
            .setTimeRange(startTime, endTime, TimeUnit.MILLISECONDS)
            .bucketByTime(1, TimeUnit.DAYS)
            .build()

        GoogleSignIn.getLastSignedInAccount(this)?.let {
            Fitness.getHistoryClient(this, it)
                .readData(readRequest)
                .addOnSuccessListener { Log.d(LOG_TAG, "onSuccess()"); }
                .addOnFailureListener { e -> Log.e(LOG_TAG, "onFailure()", e); }
                .addOnCompleteListener { Log.d(LOG_TAG, "onComplete()"); }
        }
    }*/
    override fun onDestroy()
    {
        val e = pref.edit()
        e.put(PERSON_ACTIVITY_STRING, Singleton.personActivity)
        e.apply()
        super.onDestroy()
    }

    private fun SharedPreferences.Editor.put(string: String, person: PersonActivity)
    {
        putString(string, "PersonActivity")
        putInt("Number_of_drunk_water_+$string", person.countOfDrunkWater)
        putFloat("Covered_distance_+$string", person.coveredDistance)
        putInt("Number_of_steps_+$string", person.numberOfSteps)
        putFloat("Current_weight_+$string", person.currentWeight)
    }
    private fun SharedPreferences.getPersonActivityData(string: String): PersonActivity
    {
        val countOfDrunkWater = getInt("Number_of_drunk_water_+$string", 0)
        val coveredDistance = getFloat("Covered_distance_+$string", 0.0f)
        val numberOfSteps = getInt("Number_of_steps_+$string", 0)
        val currentWeight = getFloat("Current_weight_+$string", 0.0f)
        return PersonActivity(countOfDrunkWater, coveredDistance, numberOfSteps, currentWeight)
    }
}
