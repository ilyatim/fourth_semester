package com.example.testcoursework.data

object Singleton
{
    var personActivity = PersonActivity(0, 0.0f, 0, 0.0f)
}